Daily market/macro data (free sources, no API keys).
csv/<NAME>.csv : Date,Open,High,Low,Close,Volume (series from FRED have Close only).
Date = trading-session date in the exchange's local time (US sessions close ~20:00-21:00 UTC).
daily_close_all.csv : Close of every series in one table (empty where a market was closed).
report.json : which source was used per series, row counts, date range, failed attempts.
Series marked proxy in report.json (exact=false) are substitutes (ETF or broad dollar index).
